import express from 'express';
import bcrypt from 'bcrypt';
import { storage } from '../storage';
import { createVerificationRequest, verifyEmail } from '../auth/email-verification';
import { z } from 'zod';

const router = express.Router();

// User registration schema
const registerSchema = z.object({
  username: z.string().min(3).max(50),
  password: z.string().min(6),
  email: z.string().email(),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  role: z.enum(['learner', 'assessor', 'training_provider', 'iqa', 'admin', 'operations']),
});

// Login schema
const loginSchema = z.object({
  username: z.string(),
  password: z.string(),
});

// Register a new user
router.post('/register', async (req, res) => {
  try {
    const validatedData = registerSchema.parse(req.body);
    
    // Check if username already exists
    const existingUser = await storage.getUserByUsername(validatedData.username);
    if (existingUser) {
      return res.status(400).json({ message: 'Username already exists' });
    }
    
    // Check if email already exists
    const userWithEmail = await storage.getUserByEmail(validatedData.email);
    if (userWithEmail) {
      return res.status(400).json({ message: 'Email already exists' });
    }
    
    // Hash password
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(validatedData.password, saltRounds);
    
    // Create user
    const user = await storage.createUser({
      ...validatedData,
      password: hashedPassword,
      status: 'unverified', // Initial status is unverified until email is confirmed
      avatarUrl: null,
      createdAt: new Date(),
      lastLoginAt: null
    });
    
    // Send verification email
    await createVerificationRequest(user.id, user.email);
    
    // Return success without sending the full user object for security
    res.status(201).json({ 
      message: 'User registered successfully. Please check your email to verify your account.',
      userId: user.id
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Invalid data', errors: error.errors });
    }
    console.error('Error in user registration:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const validatedData = loginSchema.parse(req.body);
    
    // Find user by username
    const user = await storage.getUserByUsername(validatedData.username);
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Check if user is active - temporarily commented out for testing
    // For the demo, let's allow login regardless of status
    /*
    if (user.status === 'unverified') {
      return res.status(401).json({ message: 'Email not verified. Please check your email for verification link.' });
    }
    
    if (user.status === 'suspended' || user.status === 'deactivated') {
      return res.status(401).json({ message: 'Account is not active. Please contact admin.' });
    }
    */
    
    // Verify password
    const passwordMatch = await bcrypt.compare(validatedData.password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Update last login time
    await storage.updateUser(user.id, {
      lastLoginAt: new Date()
    });
    
    // Create session
    if (req.session) {
      req.session.userId = user.id;
      req.session.userRole = user.role;
    }
    
    // Return user info (excluding password)
    const { password, ...userWithoutPassword } = user;
    res.json({ 
      message: 'Login successful',
      user: userWithoutPassword
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Invalid data', errors: error.errors });
    }
    console.error('Error in user login:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  if (req.session) {
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ message: 'Error logging out' });
      }
      res.json({ message: 'Logout successful' });
    });
  } else {
    res.json({ message: 'No active session' });
  }
});

// Get current authenticated user
router.get('/me', async (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  try {
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      req.session.destroy(() => {}); // Destroy invalid session
      return res.status(401).json({ message: 'User not found' });
    }
    
    // Return user info (excluding password)
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (error) {
    console.error('Error fetching current user:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Email verification endpoint
router.get('/verify-email/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const success = await verifyEmail(token);
    
    if (success) {
      // Redirect to success page
      return res.redirect('/verification-success');
    } else {
      // Redirect to error page
      return res.redirect('/verification-error');
    }
  } catch (error) {
    console.error('Error verifying email:', error);
    return res.redirect('/verification-error');
  }
});

// Test endpoint to get verification token (only for testing)
router.get('/test/get-verification-token/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const id = parseInt(userId, 10);
    
    if (!id) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const verification = await storage.getEmailVerificationByUserId(id);
    if (!verification) {
      return res.status(404).json({ message: 'Verification record not found' });
    }
    
    res.json({ token: verification.token });
  } catch (error) {
    console.error('Error getting verification token:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Test endpoint to check user status (only for testing)
router.get('/test/user-status/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const id = parseInt(userId, 10);
    
    if (!id) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const user = await storage.getUser(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.json({ status: user.status });
  } catch (error) {
    console.error('Error checking user status:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Resend verification email
router.post('/resend-verification', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }
    
    const user = await storage.getUserByEmail(email);
    if (!user) {
      // Don't reveal that the email doesn't exist for security
      return res.json({ message: 'If your email exists in our system, a verification link has been sent.' });
    }
    
    if (user.status !== 'unverified') {
      return res.json({ message: 'Your account is already verified.' });
    }
    
    // Send verification email
    await createVerificationRequest(user.id, user.email);
    
    res.json({ message: 'If your email exists in our system, a verification link has been sent.' });
  } catch (error) {
    console.error('Error resending verification email:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;