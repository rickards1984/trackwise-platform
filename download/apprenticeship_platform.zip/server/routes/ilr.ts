import { Router, Request, Response } from "express";
import fileUpload from "express-fileupload";
import { parse } from "csv-parse";
import { stringify } from "csv-stringify";
import fs from "fs";
import path from "path";
import { 
  insertIlrFileUploadSchema, 
  insertIlrLearnerRecordSchema, 
  insertIlrValidationResultSchema 
} from "@shared/schema";
import { db } from "../db";
import { 
  ilrFileUploads, 
  ilrLearnerRecords, 
  ilrValidationResults, 
  ilrValidationRules 
} from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

const router = Router();

// Set up file upload middleware
router.use(fileUpload({
  useTempFiles: true,
  tempFileDir: "./temp",
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max file size
  abortOnLimit: true,
}));

// Middleware to check if user has admin/operations permissions
const hasIlrAccessPermission = (req: Request, res: Response, next: Function) => {
  const allowedRoles = ['admin', 'training_provider', 'assessor', 'iqa', 'operations'];
  
  if (!req.session?.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  if (!allowedRoles.includes(req.session.role)) {
    return res.status(403).json({ message: "Forbidden - You don't have permission to access ILR tools" });
  }
  
  next();
};

// Middleware to check if user has admin/operations edit permissions
const hasIlrEditPermission = (req: Request, res: Response, next: Function) => {
  const allowedRoles = ['admin', 'operations'];
  
  if (!req.session?.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  if (!allowedRoles.includes(req.session.role)) {
    return res.status(403).json({ message: "Forbidden - You don't have permission to modify ILR data" });
  }
  
  next();
};

// Get all ILR file uploads (paginated)
router.get("/files", hasIlrAccessPermission, async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const offset = (page - 1) * limit;
    
    const files = await db.select()
      .from(ilrFileUploads)
      .orderBy(desc(ilrFileUploads.uploadDate))
      .limit(limit)
      .offset(offset);
    
    const totalCount = await db.select({ count: db.fn.count() })
      .from(ilrFileUploads)
      .then(result => Number(result[0].count) || 0);
    
    const totalPages = Math.ceil(totalCount / limit);
    
    res.json({
      data: files,
      pagination: {
        total: totalCount,
        totalPages,
        currentPage: page,
        limit
      }
    });
  } catch (error) {
    console.error("Error fetching ILR files:", error);
    res.status(500).json({ message: "Failed to fetch ILR files" });
  }
});

// Get a single ILR file by ID
router.get("/files/:id", hasIlrAccessPermission, async (req: Request, res: Response) => {
  try {
    const fileId = parseInt(req.params.id);
    
    if (isNaN(fileId)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const [file] = await db.select()
      .from(ilrFileUploads)
      .where(eq(ilrFileUploads.id, fileId));
    
    if (!file) {
      return res.status(404).json({ message: "ILR file not found" });
    }
    
    res.json(file);
  } catch (error) {
    console.error("Error fetching ILR file:", error);
    res.status(500).json({ message: "Failed to fetch ILR file" });
  }
});

// Upload a new ILR file
router.post("/upload", hasIlrEditPermission, async (req: Request, res: Response) => {
  try {
    if (!req.files || !req.files.ilrFile) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    
    const ilrFile = req.files.ilrFile as fileUpload.UploadedFile;
    const academicYear = req.body.academicYear;
    const returnPeriod = parseInt(req.body.returnPeriod);
    
    if (!academicYear || isNaN(returnPeriod)) {
      return res.status(400).json({ 
        message: "Missing required fields: academicYear and returnPeriod are required" 
      });
    }
    
    // Create a unique filename
    const timestamp = Date.now();
    const uniqueFilename = `ilr_${timestamp}_${ilrFile.name}`;
    const uploadDir = "./uploads/ilr";
    const filePath = path.join(uploadDir, uniqueFilename);
    
    // Ensure upload directory exists
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    // Move the file to the uploads directory
    await ilrFile.mv(filePath);
    
    // Create a database record for the uploaded file
    const validatedData = insertIlrFileUploadSchema.parse({
      filename: ilrFile.name,
      fileUrl: `/uploads/ilr/${uniqueFilename}`,
      uploadedById: req.session.userId,
      fileSize: ilrFile.size,
      academicYear,
      returnPeriod,
      status: 'pending'
    });
    
    const [newFile] = await db.insert(ilrFileUploads)
      .values(validatedData)
      .returning();
    
    // Start the validation process asynchronously
    // In a production environment, this would be done in a separate worker/queue
    setTimeout(() => validateIlrFile(newFile.id), 100);
    
    res.status(201).json({
      message: "File uploaded successfully and scheduled for validation",
      file: newFile
    });
  } catch (error) {
    console.error("Error uploading ILR file:", error);
    res.status(500).json({ message: "Failed to upload ILR file" });
  }
});

// Get validation results for a specific ILR file
router.get("/files/:id/validation", hasIlrAccessPermission, async (req: Request, res: Response) => {
  try {
    const fileId = parseInt(req.params.id);
    
    if (isNaN(fileId)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const [file] = await db.select()
      .from(ilrFileUploads)
      .where(eq(ilrFileUploads.id, fileId));
    
    if (!file) {
      return res.status(404).json({ message: "ILR file not found" });
    }
    
    const validationResults = await db.select()
      .from(ilrValidationResults)
      .where(eq(ilrValidationResults.ilrFileId, fileId));
    
    res.json({
      fileId,
      status: file.status,
      validationReport: file.validationReport,
      results: validationResults
    });
  } catch (error) {
    console.error("Error fetching validation results:", error);
    res.status(500).json({ message: "Failed to fetch validation results" });
  }
});

// Get learner records from a specific ILR file
router.get("/files/:id/learners", hasIlrAccessPermission, async (req: Request, res: Response) => {
  try {
    const fileId = parseInt(req.params.id);
    
    if (isNaN(fileId)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = (page - 1) * limit;
    
    const learners = await db.select()
      .from(ilrLearnerRecords)
      .where(eq(ilrLearnerRecords.ilrFileId, fileId))
      .limit(limit)
      .offset(offset);
    
    const totalCount = await db.select({ count: db.fn.count() })
      .from(ilrLearnerRecords)
      .where(eq(ilrLearnerRecords.ilrFileId, fileId))
      .then(result => Number(result[0].count) || 0);
    
    const totalPages = Math.ceil(totalCount / limit);
    
    res.json({
      data: learners,
      pagination: {
        total: totalCount,
        totalPages,
        currentPage: page,
        limit
      }
    });
  } catch (error) {
    console.error("Error fetching ILR learners:", error);
    res.status(500).json({ message: "Failed to fetch ILR learners" });
  }
});

// Helper function to validate an ILR file
async function validateIlrFile(fileId: number) {
  try {
    // Update file status to validating
    await db.update(ilrFileUploads)
      .set({ status: 'validating' })
      .where(eq(ilrFileUploads.id, fileId));
    
    // Get the file record
    const [file] = await db.select()
      .from(ilrFileUploads)
      .where(eq(ilrFileUploads.id, fileId));
    
    if (!file) {
      console.error(`File not found: ${fileId}`);
      return;
    }
    
    const filePath = '.' + file.fileUrl;
    
    // Check if file exists
    if (!fs.existsSync(filePath)) {
      await db.update(ilrFileUploads)
        .set({ 
          status: 'error', 
          errorDetails: 'File not found on disk' 
        })
        .where(eq(ilrFileUploads.id, fileId));
      return;
    }
    
    // In a real implementation, this would process the actual ILR XML/CSV
    // For this demo, we'll simulate parsing CSV data and validation
    
    // Mock validation errors (in a real system, these would come from actual validation)
    const validationErrors = [
      {
        ruleId: 'R01',
        learnRefNumber: 'L12345',
        severity: 'Error',
        message: 'Date of birth is invalid',
        details: { field: 'DateOfBirth', value: '2010-13-45' },
        recordNumber: 3
      },
      {
        ruleId: 'R02',
        learnRefNumber: 'L67890',
        severity: 'Warning',
        message: 'Postcode format is incorrect',
        details: { field: 'Postcode', value: 'ABC123' },
        recordNumber: 7
      }
    ];
    
    // Store validation results
    for (const error of validationErrors) {
      const validatedData = insertIlrValidationResultSchema.parse({
        ilrFileId: fileId,
        ruleId: error.ruleId,
        learnRefNumber: error.learnRefNumber,
        severity: error.severity,
        message: error.message,
        details: error.details,
        recordNumber: error.recordNumber
      });
      
      await db.insert(ilrValidationResults)
        .values(validatedData);
    }
    
    // Mock learner records
    const learnerRecords = [
      {
        learnRefNumber: 'L12345',
        ukprn: '12345678',
        uln: '1234567890',
        firstName: 'John',
        lastName: 'Smith',
        dateOfBirth: new Date('1995-06-15'),
        learningAimReference: 'ZPROG001',
        learningStartDate: new Date('2023-09-01'),
        learningPlannedEndDate: new Date('2025-08-31'),
        fundingModel: 36,
        completionStatus: 1,
        postcode: 'AB12 3CD',
        rawData: { /* Full learner record would go here */ }
      },
      {
        learnRefNumber: 'L67890',
        ukprn: '12345678',
        uln: '0987654321',
        firstName: 'Sarah',
        lastName: 'Jones',
        dateOfBirth: new Date('1998-02-22'),
        learningAimReference: 'ZPROG002',
        learningStartDate: new Date('2023-09-01'),
        learningPlannedEndDate: new Date('2025-08-31'),
        fundingModel: 36,
        completionStatus: 1,
        postcode: 'XY9 8ZW',
        rawData: { /* Full learner record would go here */ }
      }
    ];
    
    // Store learner records
    for (const learner of learnerRecords) {
      const validatedData = insertIlrLearnerRecordSchema.parse({
        ilrFileId: fileId,
        ...learner
      });
      
      await db.insert(ilrLearnerRecords)
        .values(validatedData);
    }
    
    // Update validation status
    const hasErrors = validationErrors.some(error => error.severity === 'Error');
    
    await db.update(ilrFileUploads)
      .set({ 
        status: hasErrors ? 'error' : 'complete',
        validationReport: {
          totalRecords: learnerRecords.length,
          errorCount: validationErrors.filter(e => e.severity === 'Error').length,
          warningCount: validationErrors.filter(e => e.severity === 'Warning').length,
          validationTimestamp: new Date().toISOString()
        }
      })
      .where(eq(ilrFileUploads.id, fileId));
    
  } catch (error) {
    console.error(`Error validating ILR file ${fileId}:`, error);
    
    // Update status to error
    await db.update(ilrFileUploads)
      .set({ 
        status: 'error', 
        errorDetails: `Internal error: ${error.message}` 
      })
      .where(eq(ilrFileUploads.id, fileId));
  }
}

export default router;