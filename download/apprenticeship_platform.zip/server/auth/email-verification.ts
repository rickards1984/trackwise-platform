import crypto from 'crypto';
import { storage } from '../storage';
import { InsertEmailVerification } from '@shared/schema';
import { sendVerificationEmail } from '../services/email';

/**
 * Generate a random verification token
 */
export function generateVerificationToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Create a verification record and send verification email
 */
export async function createVerificationRequest(userId: number, email: string): Promise<boolean> {
  try {
    // Check if a verification record already exists for this user
    const existingVerification = await storage.getEmailVerificationByUserId(userId);
    
    // If there is an existing verification and it's verified, no need to create a new one
    if (existingVerification && existingVerification.verified) {
      return true;
    }
    
    // Generate a token that expires in 24 hours
    const token = generateVerificationToken();
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);
    
    const verificationData: InsertEmailVerification = {
      userId,
      email,
      token,
      expiresAt,
      verified: false
    };
    
    // Create or update verification record
    if (existingVerification) {
      await storage.updateEmailVerification(existingVerification.id, verificationData);
    } else {
      await storage.createEmailVerification(verificationData);
    }
    
    // Send email with verification link
    return await sendVerificationEmail(email, token);
  } catch (error) {
    console.error('Error creating verification request:', error);
    return false;
  }
}

/**
 * Verify email using token
 */
export async function verifyEmail(token: string): Promise<boolean> {
  try {
    // Find verification record by token
    const verification = await storage.getEmailVerificationByToken(token);
    
    if (!verification) {
      return false;
    }
    
    // Check if token is expired
    const now = new Date();
    if (now > verification.expiresAt) {
      return false;
    }
    
    // Check if already verified
    if (verification.verified) {
      return true;
    }
    
    // Update verification status
    await storage.updateEmailVerification(verification.id, {
      verified: true
    });
    
    // The verifiedAt field will be set by a trigger or in the DatabaseStorage implementation
    
    // Update user status from 'unverified' to 'active'
    const user = await storage.getUser(verification.userId);
    if (user && user.status === 'unverified') {
      // Get a new reference to the user to update separately
      const userToUpdate = await storage.getUser(verification.userId);
      
      // Directly update the user in storage
      if (userToUpdate) {
        userToUpdate.status = 'active';
        await storage.updateUserStatus(userToUpdate.id, 'active');
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error verifying email:', error);
    return false;
  }
}

/**
 * Check if a user's email is verified
 */
export async function isEmailVerified(userId: number): Promise<boolean> {
  try {
    const verification = await storage.getEmailVerificationByUserId(userId);
    return verification ? verification.verified : false;
  } catch (error) {
    console.error('Error checking email verification status:', error);
    return false;
  }
}