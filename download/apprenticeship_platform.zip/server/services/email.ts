import nodemailer from 'nodemailer';

// Create a testing transport for development - in production this should use proper SMTP settings
const transporter = nodemailer.createTransport({
  host: 'smtp.ethereal.email',
  port: 587,
  secure: false,
  auth: {
    user: 'demo@example.com', // In production, this should come from environment variables
    pass: 'password123'       // In production, this should come from environment variables
  }
});

// Set up a default "from" email address
const defaultFromEmail = 'noreply@apprenticeship-platform.com';

/**
 * Send a verification email to a user
 * @param to The recipient's email address
 * @param token The verification token
 * @returns Promise<boolean> Whether the email was sent successfully
 */
export async function sendVerificationEmail(to: string, token: string): Promise<boolean> {
  try {
    // In production, this URL should come from environment variables or configuration
    const verificationUrl = `http://localhost:5000/api/v2/auth/verify-email/${token}`;
    
    const mailOptions = {
      from: defaultFromEmail,
      to,
      subject: 'Verify Your Email Address',
      text: `Please verify your email address by clicking on the following link: ${verificationUrl}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Email Verification</h2>
          <p>Thank you for registering with our Apprenticeship Platform. Please verify your email address by clicking the button below:</p>
          <div style="text-align: center; margin: 25px 0;">
            <a href="${verificationUrl}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Verify Email</a>
          </div>
          <p>If the button doesn't work, you can also copy and paste the following link into your browser:</p>
          <p><a href="${verificationUrl}">${verificationUrl}</a></p>
          <p>This link will expire in 24 hours.</p>
          <hr style="border: 1px solid #eee; margin: 20px 0;">
          <p style="color: #777; font-size: 12px;">If you didn't request this verification, please ignore this email.</p>
        </div>
      `
    };
    
    // For development, just log the email instead of actually sending it
    console.log('Sending verification email to:', to);
    console.log('Verification URL:', verificationUrl);
    
    // In production, uncomment this code to actually send the email
    // await transporter.sendMail(mailOptions);
    
    return true;
  } catch (error) {
    console.error('Error sending verification email:', error);
    return false;
  }
}

/**
 * Send a password reset email to a user
 * @param to The recipient's email address
 * @param token The password reset token
 * @returns Promise<boolean> Whether the email was sent successfully
 */
export async function sendPasswordResetEmail(to: string, token: string): Promise<boolean> {
  try {
    // In production, this URL should come from environment variables or configuration
    const resetUrl = `http://localhost:5000/reset-password/${token}`;
    // Note: The reset password URL points to the frontend route, not the API
    
    const mailOptions = {
      from: defaultFromEmail,
      to,
      subject: 'Reset Your Password',
      text: `You requested a password reset. Please click on the following link to reset your password: ${resetUrl}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Password Reset</h2>
          <p>You requested a password reset for your Apprenticeship Platform account. Please click the button below to reset your password:</p>
          <div style="text-align: center; margin: 25px 0;">
            <a href="${resetUrl}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
          </div>
          <p>If the button doesn't work, you can also copy and paste the following link into your browser:</p>
          <p><a href="${resetUrl}">${resetUrl}</a></p>
          <p>This link will expire in 1 hour.</p>
          <hr style="border: 1px solid #eee; margin: 20px 0;">
          <p style="color: #777; font-size: 12px;">If you didn't request this password reset, please ignore this email or contact support if you have concerns.</p>
        </div>
      `
    };
    
    // For development, just log the email instead of actually sending it
    console.log('Sending password reset email to:', to);
    console.log('Reset URL:', resetUrl);
    
    // In production, uncomment this code to actually send the email
    // await transporter.sendMail(mailOptions);
    
    return true;
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return false;
  }
}

/**
 * Send a notification email to a user
 * @param to The recipient's email address
 * @param subject The email subject
 * @param message The message content
 * @returns Promise<boolean> Whether the email was sent successfully
 */
export async function sendNotificationEmail(to: string, subject: string, message: string): Promise<boolean> {
  try {
    const mailOptions = {
      from: defaultFromEmail,
      to,
      subject,
      text: message,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Apprenticeship Platform Notification</h2>
          <div style="padding: 20px; border: 1px solid #eee; border-radius: 5px;">
            ${message}
          </div>
          <hr style="border: 1px solid #eee; margin: 20px 0;">
          <p style="color: #777; font-size: 12px;">This is an automated message from the Apprenticeship Platform.</p>
        </div>
      `
    };
    
    // For development, just log the email instead of actually sending it
    console.log('Sending notification email to:', to);
    console.log('Subject:', subject);
    console.log('Message:', message);
    
    // In production, uncomment this code to actually send the email
    // await transporter.sendMail(mailOptions);
    
    return true;
  } catch (error) {
    console.error('Error sending notification email:', error);
    return false;
  }
}