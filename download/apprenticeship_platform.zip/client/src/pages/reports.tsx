import { useState, useContext } from "react";
import { useQuery } from "@tanstack/react-query";
import { AuthContext } from "@/App";
import AppHeader from "@/components/layout/app-header";
import Sidebar from "@/components/layout/sidebar";
import AppFooter from "@/components/layout/app-footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  BarChart as BarChartIcon,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon,
  Calendar,
  FileDown,
  Download,
  AreaChart
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";

const COLORS = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

// Weekly OTJ hours data (would come from API)
const weeklyOtjData = [
  { week: 'Week 1', hours: 7.5, target: 6 },
  { week: 'Week 2', hours: 6, target: 6 },
  { week: 'Week 3', hours: 8, target: 6 },
  { week: 'Week 4', hours: 5, target: 6 },
  { week: 'Week 5', hours: 9, target: 6 },
  { week: 'Week 6', hours: 6.5, target: 6 },
  { week: 'Week 7', hours: 7, target: 6 },
  { week: 'Week 8', hours: 4.5, target: 6 },
];

// KSB progress data (would come from API)
const ksbProgressData = [
  { name: 'Knowledge', achieved: 7, total: 9 },
  { name: 'Skills', achieved: 6, total: 8 },
  { name: 'Behaviors', achieved: 5, total: 7 },
];

// Evidence by status data (would come from API)
const evidenceStatusData = [
  { name: 'Approved', value: 12 },
  { name: 'In Review', value: 4 },
  { name: 'Needs Revision', value: 2 },
  { name: 'Draft', value: 3 },
];

// Activity type distribution data (would come from API)
const activityTypeData = [
  { name: 'Research', hours: 15 },
  { name: 'Workshop', hours: 12 },
  { name: 'Project', hours: 22 },
  { name: 'Mentoring', hours: 8 },
  { name: 'Course', hours: 18 },
  { name: 'Other', hours: 5 },
];

export default function Reports() {
  const { user } = useContext(AuthContext);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [timeRange, setTimeRange] = useState("3months");

  // Format percentage for the pie chart
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * Math.PI / 180);
    const y = cy + radius * Math.sin(-midAngle * Math.PI / 180);
  
    return (
      <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <AppHeader toggleSidebar={toggleSidebar} />
      <div className="flex flex-1">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <main className="md:ml-64 flex-1">
          <div className="py-6 max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-semibold text-neutral-900">Progress Reports</h1>
                <p className="mt-1 text-sm text-neutral-500">
                  View and analyze your apprenticeship progress
                </p>
              </div>
              <div className="mt-4 md:mt-0 flex gap-2">
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-[160px]">
                    <Calendar className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Time Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1month">Last Month</SelectItem>
                    <SelectItem value="3months">Last 3 Months</SelectItem>
                    <SelectItem value="6months">Last 6 Months</SelectItem>
                    <SelectItem value="1year">Last Year</SelectItem>
                    <SelectItem value="all">All Time</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <FileDown className="h-4 w-4 mr-2" />
                  Export Report
                </Button>
              </div>
            </div>

            <Tabs defaultValue="otj" className="mb-6">
              <TabsList className="mb-4">
                <TabsTrigger value="otj" className="flex items-center">
                  <BarChartIcon className="h-4 w-4 mr-2" />
                  OTJ Hours
                </TabsTrigger>
                <TabsTrigger value="ksb" className="flex items-center">
                  <LineChartIcon className="h-4 w-4 mr-2" />
                  KSB Progress
                </TabsTrigger>
                <TabsTrigger value="evidence" className="flex items-center">
                  <PieChartIcon className="h-4 w-4 mr-2" />
                  Evidence
                </TabsTrigger>
                <TabsTrigger value="activities" className="flex items-center">
                  <AreaChart className="h-4 w-4 mr-2" />
                  Activities
                </TabsTrigger>
              </TabsList>
              
              {/* OTJ Hours Tab */}
              <TabsContent value="otj">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Weekly OTJ Hours</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={weeklyOtjData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="week" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="hours" fill="#2563EB" name="Hours Logged" />
                          <Bar dataKey="target" fill="#10B981" name="Target Hours" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-4 flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium">Total Hours: <span className="text-primary">54 hours</span></p>
                        <p className="text-sm text-neutral-500">Target: 48 hours (6 hours/week)</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Download Chart
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* KSB Progress Tab */}
              <TabsContent value="ksb">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">KSB Progress Over Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={[
                              { month: 'Jan', knowledge: 2, skills: 1, behaviors: 1 },
                              { month: 'Feb', knowledge: 3, skills: 2, behaviors: 2 },
                              { month: 'Mar', knowledge: 4, skills: 3, behaviors: 3 },
                              { month: 'Apr', knowledge: 5, skills: 4, behaviors: 3 },
                              { month: 'May', knowledge: 7, skills: 6, behaviors: 5 }
                            ]}
                            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="knowledge" stroke="#2563EB" name="Knowledge" />
                            <Line type="monotone" dataKey="skills" stroke="#10B981" name="Skills" />
                            <Line type="monotone" dataKey="behaviors" stroke="#F59E0B" name="Behaviors" />
                          </LineChart>
                        </ResponsiveContainer>
                        <p className="text-sm text-neutral-500 text-center mt-2">Progress over last 5 months</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium mb-4">Current KSB Status</h3>
                        {ksbProgressData.map((item, index) => (
                          <div key={index} className="mb-4">
                            <div className="flex justify-between text-sm mb-1">
                              <span className="font-medium">{item.name}</span>
                              <span className="text-neutral-500">{item.achieved} / {item.total} completed</span>
                            </div>
                            <div className="w-full bg-neutral-200 rounded-full h-2.5">
                              <div
                                className="h-2.5 rounded-full"
                                style={{
                                  width: `${(item.achieved / item.total) * 100}%`,
                                  backgroundColor: COLORS[index % COLORS.length]
                                }}
                              ></div>
                            </div>
                          </div>
                        ))}
                        
                        <div className="border-t pt-4 mt-4">
                          <h3 className="text-sm font-medium mb-2">Summary</h3>
                          <p className="text-sm text-neutral-600 mb-2">
                            You have completed <span className="font-medium">18 out of 24</span> KSBs, which is <span className="font-medium text-primary">75%</span> of the total.
                          </p>
                          <p className="text-sm text-neutral-600">
                            Based on your current progress, you are ahead of schedule for your apprenticeship completion.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Evidence Tab */}
              <TabsContent value="evidence">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Evidence Submission Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={evidenceStatusData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={renderCustomizedLabel}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                            >
                              {evidenceStatusData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                        <p className="text-sm text-neutral-500 text-center mt-2">Evidence by Status</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium mb-4">Evidence Submission Stats</h3>
                        <div className="space-y-4">
                          <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                            <div className="text-xl font-bold">21</div>
                            <div className="text-sm text-neutral-500">Total Evidence Items</div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                              <div className="text-xl font-bold text-emerald-600">57%</div>
                              <div className="text-sm text-neutral-500">Approval Rate</div>
                            </div>
                            <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                              <div className="text-xl font-bold text-amber-500">3.2</div>
                              <div className="text-sm text-neutral-500">Avg. Review Days</div>
                            </div>
                          </div>
                          
                          <div className="border-t pt-4">
                            <h3 className="text-sm font-medium mb-2">Recent Activity</h3>
                            <ul className="space-y-2 text-sm">
                              <li className="flex justify-between">
                                <span>Evidence Submitted</span>
                                <span className="text-neutral-500">3 this month</span>
                              </li>
                              <li className="flex justify-between">
                                <span>Evidence Approved</span>
                                <span className="text-neutral-500">2 this month</span>
                              </li>
                              <li className="flex justify-between">
                                <span>Pending Review</span>
                                <span className="text-neutral-500">4 items</span>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Activities Tab */}
              <TabsContent value="activities">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Activity Type Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={activityTypeData}
                          layout="vertical"
                          margin={{ top: 20, right: 30, left: 60, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" />
                          <YAxis dataKey="name" type="category" />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="hours" fill="#2563EB" name="Hours Spent" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200">
                        <div className="text-lg font-bold">80</div>
                        <div className="text-xs text-neutral-500">Total Activity Hours</div>
                      </div>
                      <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200">
                        <div className="text-lg font-bold text-primary">Project</div>
                        <div className="text-xs text-neutral-500">Most Common Activity</div>
                      </div>
                      <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200">
                        <div className="text-lg font-bold text-emerald-600">22 hrs</div>
                        <div className="text-xs text-neutral-500">Project Work Hours</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
      <AppFooter />
    </div>
  );
}
