import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";

import AppHeader from "@/components/layout/app-header";
import Sidebar from "@/components/layout/sidebar";
import AppFooter from "@/components/layout/app-footer";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, BookOpen, FileText, Layers, Plus, Trash2, Upload, Wand2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { StandardAnalyzer } from "@/components/ai-assistant/StandardAnalyzer";

// Form schema for creating a new course template
const courseTemplateSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  standardId: z.coerce.number().min(1, "Standard is required"),
  isPublic: z.boolean().default(false),
  includeResources: z.boolean().default(true),
  includeAssessments: z.boolean().default(true),
});

type CourseTemplateFormValues = z.infer<typeof courseTemplateSchema>;

// Building blocks for a course
interface ModuleBlock {
  id: string;
  title: string;
  description: string;
  ksbIds: number[];
  order: number;
  lessons: LessonBlock[];
}

interface LessonBlock {
  id: string;
  moduleId: string;
  title: string;
  description: string;
  type: "content" | "assessment" | "resource";
  ksbIds: number[];
  order: number;
  content?: string;
}

// Component for the AI Course Builder
export default function CourseBuilder() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("builder");
  const [showStandardAnalyzer, setShowStandardAnalyzer] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [courseModules, setCourseModules] = useState<ModuleBlock[]>([]);
  const [selectedModule, setSelectedModule] = useState<string | null>(null);
  const [standardKSBs, setStandardKSBs] = useState<any[]>([]);
  const [aiSuggestions, setAiSuggestions] = useState<any[]>([]);
  const [aiGenerating, setAiGenerating] = useState(false);
  
  // Get available apprenticeship standards
  const { data: standards, isLoading: standardsLoading } = useQuery({
    queryKey: ["/api/standards"],
    enabled: !authLoading && !!user,
  });

  // Get templates
  const { data: templates, isLoading: templatesLoading } = useQuery({
    queryKey: ["/api/course-builder/templates"],
    enabled: !authLoading && !!user,
  });

  // Form for creating a new course template
  const form = useForm<CourseTemplateFormValues>({
    resolver: zodResolver(courseTemplateSchema),
    defaultValues: {
      title: "",
      description: "",
      standardId: 0,
      isPublic: false,
      includeResources: true,
      includeAssessments: true,
    },
  });

  // When standard changes, fetch KSBs for that standard
  useEffect(() => {
    const standardId = form.watch("standardId");
    if (standardId) {
      // Fetch KSBs for this standard
      const fetchKSBs = async () => {
        try {
          const response = await apiRequest(`/api/ksbs?standardId=${standardId}`, {
            method: "GET",
          });
          setStandardKSBs(response);
        } catch (error) {
          console.error("Error fetching KSBs:", error);
          toast({
            title: "Error",
            description: "Failed to fetch KSBs for the selected standard",
            variant: "destructive",
          });
        }
      };
      fetchKSBs();
    }
  }, [form.watch("standardId")]);

  // Create new template mutation
  const createTemplateMutation = useMutation({
    mutationFn: async (values: CourseTemplateFormValues) => {
      return apiRequest("/api/course-builder/templates", {
        method: "POST",
        data: values,
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Course template created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/course-builder/templates"] });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create course template",
        variant: "destructive",
      });
    },
  });

  // Generate course structure with AI
  const generateCourseStructure = async () => {
    try {
      setAiGenerating(true);
      const standardId = form.getValues("standardId");
      if (!standardId) {
        toast({
          title: "Required",
          description: "Please select an apprenticeship standard first",
          variant: "destructive",
        });
        setAiGenerating(false);
        return;
      }

      // Call the API to generate course structure using AI
      const generated = await apiRequest("/api/course-builder/generate-structure", {
        method: "POST",
        data: {
          standardId,
          includeResources: form.getValues("includeResources"),
          includeAssessments: form.getValues("includeAssessments"),
        },
      });

      if (generated?.modules) {
        setCourseModules(generated.modules);
        toast({
          title: "Success",
          description: "AI has generated a course structure based on the selected standard",
        });
      }
    } catch (error) {
      console.error("Error generating course structure:", error);
      toast({
        title: "Error",
        description: "Failed to generate course structure with AI",
        variant: "destructive",
      });
    } finally {
      setAiGenerating(false);
    }
  };

  // Add new module
  const addModule = () => {
    const newModule: ModuleBlock = {
      id: `module_${Date.now()}`,
      title: "New Module",
      description: "",
      ksbIds: [],
      order: courseModules.length + 1,
      lessons: [],
    };
    setCourseModules([...courseModules, newModule]);
    setSelectedModule(newModule.id);
  };

  // Add new lesson to module
  const addLesson = (moduleId: string, type: "content" | "assessment" | "resource") => {
    const moduleIndex = courseModules.findIndex(m => m.id === moduleId);
    if (moduleIndex !== -1) {
      const updatedModules = [...courseModules];
      const newLesson: LessonBlock = {
        id: `lesson_${Date.now()}`,
        moduleId,
        title: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
        description: "",
        type,
        ksbIds: [],
        order: updatedModules[moduleIndex].lessons.length + 1,
      };
      updatedModules[moduleIndex].lessons.push(newLesson);
      setCourseModules(updatedModules);
    }
  };

  // Update module
  const updateModule = (moduleId: string, data: Partial<Omit<ModuleBlock, "id" | "lessons">>) => {
    const moduleIndex = courseModules.findIndex(m => m.id === moduleId);
    if (moduleIndex !== -1) {
      const updatedModules = [...courseModules];
      updatedModules[moduleIndex] = {
        ...updatedModules[moduleIndex],
        ...data,
      };
      setCourseModules(updatedModules);
    }
  };

  // Update lesson
  const updateLesson = (
    moduleId: string,
    lessonId: string,
    data: Partial<Omit<LessonBlock, "id" | "moduleId">>
  ) => {
    const moduleIndex = courseModules.findIndex(m => m.id === moduleId);
    if (moduleIndex !== -1) {
      const lessonIndex = courseModules[moduleIndex].lessons.findIndex(l => l.id === lessonId);
      if (lessonIndex !== -1) {
        const updatedModules = [...courseModules];
        updatedModules[moduleIndex].lessons[lessonIndex] = {
          ...updatedModules[moduleIndex].lessons[lessonIndex],
          ...data,
        };
        setCourseModules(updatedModules);
      }
    }
  };

  // Delete module
  const deleteModule = (moduleId: string) => {
    setCourseModules(courseModules.filter(m => m.id !== moduleId));
    if (selectedModule === moduleId) {
      setSelectedModule(null);
    }
  };

  // Delete lesson
  const deleteLesson = (moduleId: string, lessonId: string) => {
    const moduleIndex = courseModules.findIndex(m => m.id === moduleId);
    if (moduleIndex !== -1) {
      const updatedModules = [...courseModules];
      updatedModules[moduleIndex].lessons = updatedModules[moduleIndex].lessons.filter(
        l => l.id !== lessonId
      );
      setCourseModules(updatedModules);
    }
  };

  // Save template with current modules and lessons
  const saveTemplate = async () => {
    try {
      const values = form.getValues();
      if (!values.title || !values.description || !values.standardId) {
        toast({
          title: "Required",
          description: "Please fill in all required fields",
          variant: "destructive",
        });
        return;
      }

      if (courseModules.length === 0) {
        toast({
          title: "Required",
          description: "Please add at least one module to your course",
          variant: "destructive",
        });
        return;
      }

      const templateData = {
        ...values,
        modules: courseModules,
      };

      const response = await apiRequest("/api/course-builder/templates", {
        method: "POST",
        data: templateData,
      });

      toast({
        title: "Success",
        description: "Course template saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/course-builder/templates"] });
    } catch (error) {
      console.error("Error saving template:", error);
      toast({
        title: "Error",
        description: "Failed to save course template",
        variant: "destructive",
      });
    }
  };

  // Handle standard analysis results
  const handleStandardAnalysisResults = (results: any) => {
    if (results && results.ksbElements) {
      setStandardKSBs(results.ksbElements);
      
      // Suggest a course structure based on the analysis
      const suggestedModules = generateSuggestedStructure(results.ksbElements);
      setCourseModules(suggestedModules);
      
      // Close the analyzer
      setShowStandardAnalyzer(false);
      
      toast({
        title: "Success",
        description: "Standard analyzed and course structure suggested successfully",
      });
    }
  };

  // Generate a suggested course structure from KSB elements
  const generateSuggestedStructure = (ksbElements: any[]) => {
    // Group KSBs by type
    const knowledgeItems = ksbElements.filter(k => k.type === 'knowledge');
    const skillItems = ksbElements.filter(k => k.type === 'skill');
    const behaviorItems = ksbElements.filter(k => k.type === 'behavior');
    
    // Create modules based on knowledge groups
    const modules: ModuleBlock[] = [];
    
    // Create a foundation module
    const foundationModule: ModuleBlock = {
      id: `module_${Date.now()}`,
      title: "Foundations and Core Knowledge",
      description: "Core knowledge and foundations for the apprenticeship",
      ksbIds: knowledgeItems.slice(0, Math.min(5, knowledgeItems.length)).map(k => k.id),
      order: 1,
      lessons: [
        {
          id: `lesson_${Date.now()}`,
          moduleId: `module_${Date.now()}`,
          title: "Introduction to the Standard",
          description: "Overview of the apprenticeship standard and expectations",
          type: "content",
          ksbIds: [],
          order: 1,
        }
      ]
    };
    modules.push(foundationModule);
    
    // Create a skills module
    if (skillItems.length > 0) {
      const skillsModule: ModuleBlock = {
        id: `module_${Date.now()+1}`,
        title: "Practical Skills Development",
        description: "Development of key practical skills",
        ksbIds: skillItems.slice(0, Math.min(5, skillItems.length)).map(k => k.id),
        order: 2,
        lessons: [
          {
            id: `lesson_${Date.now()+1}`,
            moduleId: `module_${Date.now()+1}`,
            title: "Core Skills Introduction",
            description: "Introduction to the core skills for this standard",
            type: "content",
            ksbIds: skillItems.slice(0, Math.min(3, skillItems.length)).map(k => k.id),
            order: 1,
          }
        ]
      };
      modules.push(skillsModule);
    }
    
    // Create a behaviors module
    if (behaviorItems.length > 0) {
      const behaviorsModule: ModuleBlock = {
        id: `module_${Date.now()+2}`,
        title: "Professional Behaviors",
        description: "Development of key professional behaviors",
        ksbIds: behaviorItems.slice(0, Math.min(5, behaviorItems.length)).map(k => k.id),
        order: 3,
        lessons: [
          {
            id: `lesson_${Date.now()+2}`,
            moduleId: `module_${Date.now()+2}`,
            title: "Professional Conduct and Expectations",
            description: "Introduction to professional behaviors and expectations",
            type: "content",
            ksbIds: behaviorItems.slice(0, Math.min(3, behaviorItems.length)).map(k => k.id),
            order: 1,
          }
        ]
      };
      modules.push(behaviorsModule);
    }
    
    // Add an assessment module
    const assessmentModule: ModuleBlock = {
      id: `module_${Date.now()+3}`,
      title: "Assessment Preparation",
      description: "Preparation for final assessment",
      ksbIds: [],
      order: modules.length + 1,
      lessons: [
        {
          id: `lesson_${Date.now()+3}`,
          moduleId: `module_${Date.now()+3}`,
          title: "Assessment Overview",
          description: "Overview of the assessment process and requirements",
          type: "content",
          ksbIds: [],
          order: 1,
        },
        {
          id: `lesson_${Date.now()+4}`,
          moduleId: `module_${Date.now()+3}`,
          title: "Mock Assessment",
          description: "Practice assessment activities",
          type: "assessment",
          ksbIds: [],
          order: 2,
        }
      ]
    };
    modules.push(assessmentModule);
    
    return modules;
  };

  return (
    <div className="flex min-h-screen flex-col">
      <AppHeader />

      <div className="flex flex-1">
        <Sidebar />

        <main className="flex-1 p-6">
          <div className="container mx-auto">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-3xl font-bold">Course Builder</h1>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowStandardAnalyzer(true)}
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Analyze Standard
                </Button>
              </div>
            </div>

            {showStandardAnalyzer && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Apprenticeship Standard Analyzer</CardTitle>
                  <CardDescription>
                    Upload or paste an apprenticeship standard document to analyze and extract KSBs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <StandardAnalyzer onAnalysisComplete={handleStandardAnalysisResults} />
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button variant="outline" onClick={() => setShowStandardAnalyzer(false)}>
                    Close
                  </Button>
                </CardFooter>
              </Card>
            )}

            <Tabs defaultValue="builder" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-6 grid w-full grid-cols-2">
                <TabsTrigger value="builder">Course Builder</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
              </TabsList>

              <TabsContent value="builder">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                  <Card className="lg:col-span-1">
                    <CardHeader>
                      <CardTitle>Course Details</CardTitle>
                      <CardDescription>Define your course template</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(values => createTemplateMutation.mutate(values))} className="space-y-4">
                          <FormField
                            control={form.control}
                            name="title"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Title</FormLabel>
                                <FormControl>
                                  <Input placeholder="Course title" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea
                                    placeholder="Course description"
                                    className="resize-none"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="standardId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Apprenticeship Standard</FormLabel>
                                <Select
                                  value={field.value.toString()}
                                  onValueChange={(value) => field.onChange(parseInt(value))}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select standard" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {standards?.map((standard: any) => (
                                      <SelectItem key={standard.id} value={standard.id.toString()}>
                                        {standard.title} (Level {standard.level})
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="isPublic"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                                <div className="space-y-0.5">
                                  <FormLabel>Public Template</FormLabel>
                                  <FormDescription>
                                    Make this template available to other providers
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="includeResources"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                                <div className="space-y-0.5">
                                  <FormLabel>Include Resources</FormLabel>
                                  <FormDescription>
                                    AI will suggest resources for each module
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="includeAssessments"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                                <div className="space-y-0.5">
                                  <FormLabel>Include Assessments</FormLabel>
                                  <FormDescription>
                                    AI will suggest assessments for each module
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <div className="flex flex-col gap-2 pt-2">
                            <Button
                              type="button"
                              onClick={generateCourseStructure}
                              disabled={aiGenerating || !form.getValues("standardId")}
                              className="w-full"
                            >
                              <Wand2 className="mr-2 h-4 w-4" />
                              {aiGenerating ? "Generating..." : "Generate with AI"}
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={addModule}
                              className="w-full"
                            >
                              <Plus className="mr-2 h-4 w-4" />
                              Add Module Manually
                            </Button>
                            <Button
                              type="button"
                              variant="default"
                              onClick={saveTemplate}
                              className="w-full"
                            >
                              Save Template
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>

                  <Card className="lg:col-span-3">
                    <CardHeader>
                      <CardTitle>Course Structure</CardTitle>
                      <CardDescription>Build your course structure with modules and lessons</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {courseModules.length === 0 ? (
                        <div className="text-center py-8">
                          <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
                          <h3 className="mt-2 text-lg font-medium">No modules yet</h3>
                          <p className="mt-1 text-sm text-gray-500">
                            Add modules to your course using the AI generator or manually
                          </p>
                          <div className="mt-6">
                            <Button onClick={addModule}>
                              <Plus className="mr-2 h-4 w-4" />
                              Add Module
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {courseModules.map((module) => (
                              <div 
                                key={module.id}
                                className={`border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors ${
                                  selectedModule === module.id ? 'border-primary bg-primary/5' : ''
                                }`}
                                onClick={() => setSelectedModule(module.id)}
                              >
                                <div className="flex items-start justify-between">
                                  <h3 className="font-medium">{module.title}</h3>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      deleteModule(module.id);
                                    }}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                                <p className="text-sm text-gray-500 mt-1 mb-2">
                                  {module.description || "No description"}
                                </p>
                                <div className="text-sm">
                                  {module.lessons.length} lesson{module.lessons.length !== 1 ? 's' : ''}
                                </div>
                                {module.ksbIds.length > 0 && (
                                  <div className="flex flex-wrap gap-1 mt-2">
                                    {module.ksbIds.slice(0, 3).map((ksbId) => {
                                      const ksb = standardKSBs.find(k => k.id === ksbId);
                                      return (
                                        <Badge key={ksbId} variant="outline" className="text-xs">
                                          {ksb?.code || `KSB-${ksbId}`}
                                        </Badge>
                                      );
                                    })}
                                    {module.ksbIds.length > 3 && (
                                      <Badge variant="outline" className="text-xs">
                                        +{module.ksbIds.length - 3} more
                                      </Badge>
                                    )}
                                  </div>
                                )}
                              </div>
                            ))}
                            <div 
                              className="border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors border-dashed flex items-center justify-center"
                              onClick={addModule}
                            >
                              <div className="text-center">
                                <Plus className="mx-auto h-6 w-6 text-gray-400" />
                                <span className="text-sm text-gray-500">Add Module</span>
                              </div>
                            </div>
                          </div>

                          {selectedModule && (
                            <div className="mt-8 border rounded-lg p-6">
                              <h3 className="text-lg font-medium mb-4">
                                Edit Module
                              </h3>
                              
                              {(() => {
                                const module = courseModules.find(m => m.id === selectedModule);
                                if (!module) return null;
                                
                                return (
                                  <>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                      <div className="space-y-4">
                                        <div className="space-y-2">
                                          <label className="text-sm font-medium">Title</label>
                                          <Input 
                                            value={module.title} 
                                            onChange={(e) => updateModule(module.id, { title: e.target.value })}
                                          />
                                        </div>
                                        <div className="space-y-2">
                                          <label className="text-sm font-medium">Description</label>
                                          <Textarea 
                                            value={module.description} 
                                            onChange={(e) => updateModule(module.id, { description: e.target.value })}
                                          />
                                        </div>
                                      </div>
                                      
                                      <div className="space-y-4">
                                        <div className="space-y-2">
                                          <label className="text-sm font-medium">Knowledge, Skills & Behaviors</label>
                                          <Select
                                            onValueChange={(value) => {
                                              const ksbId = parseInt(value);
                                              if (!module.ksbIds.includes(ksbId)) {
                                                updateModule(module.id, { 
                                                  ksbIds: [...module.ksbIds, ksbId] 
                                                });
                                              }
                                            }}
                                          >
                                            <SelectTrigger>
                                              <SelectValue placeholder="Add KSB" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              {standardKSBs.map((ksb) => (
                                                <SelectItem key={ksb.id} value={ksb.id.toString()}>
                                                  {ksb.code}: {ksb.description.substring(0, 50)}...
                                                </SelectItem>
                                              ))}
                                            </SelectContent>
                                          </Select>
                                          
                                          <div className="flex flex-wrap gap-2 mt-2">
                                            {module.ksbIds.map((ksbId) => {
                                              const ksb = standardKSBs.find(k => k.id === ksbId);
                                              return (
                                                <Badge 
                                                  key={ksbId} 
                                                  variant="secondary"
                                                  className="flex items-center gap-1"
                                                >
                                                  {ksb?.code || `KSB-${ksbId}`}
                                                  <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-4 w-4 p-0"
                                                    onClick={() => updateModule(module.id, { 
                                                      ksbIds: module.ksbIds.filter(id => id !== ksbId) 
                                                    })}
                                                  >
                                                    <Trash2 className="h-3 w-3" />
                                                  </Button>
                                                </Badge>
                                              );
                                            })}
                                          </div>
                                        </div>
                                        
                                        <div className="space-y-2 pt-2">
                                          <label className="text-sm font-medium">Module Order</label>
                                          <Input 
                                            type="number" 
                                            min="1" 
                                            value={module.order} 
                                            onChange={(e) => updateModule(module.id, { order: parseInt(e.target.value) })}
                                          />
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <Separator className="my-6" />
                                    
                                    <div className="mb-4 flex items-center justify-between">
                                      <h4 className="text-md font-medium">Lessons</h4>
                                      <div className="flex gap-2">
                                        <Button 
                                          variant="outline" 
                                          size="sm"
                                          onClick={() => addLesson(module.id, "content")}
                                        >
                                          <Plus className="mr-1 h-3 w-3" />
                                          Content
                                        </Button>
                                        <Button 
                                          variant="outline" 
                                          size="sm"
                                          onClick={() => addLesson(module.id, "assessment")}
                                        >
                                          <Plus className="mr-1 h-3 w-3" />
                                          Assessment
                                        </Button>
                                        <Button 
                                          variant="outline" 
                                          size="sm"
                                          onClick={() => addLesson(module.id, "resource")}
                                        >
                                          <Plus className="mr-1 h-3 w-3" />
                                          Resource
                                        </Button>
                                      </div>
                                    </div>
                                    
                                    {module.lessons.length === 0 ? (
                                      <div className="text-center py-8 border rounded-lg bg-gray-50">
                                        <AlertCircle className="mx-auto h-10 w-10 text-gray-400" />
                                        <h5 className="mt-2 text-sm font-medium">No lessons yet</h5>
                                        <p className="mt-1 text-xs text-gray-500">
                                          Add lessons to this module
                                        </p>
                                      </div>
                                    ) : (
                                      <div className="space-y-4">
                                        {module.lessons.sort((a, b) => a.order - b.order).map((lesson) => (
                                          <div key={lesson.id} className="border rounded-lg p-4">
                                            <div className="flex items-start justify-between mb-3">
                                              <div className="flex items-center gap-2">
                                                <Badge variant={
                                                  lesson.type === "content" ? "default" :
                                                  lesson.type === "assessment" ? "destructive" : "secondary"
                                                }>
                                                  {lesson.type.charAt(0).toUpperCase() + lesson.type.slice(1)}
                                                </Badge>
                                                <span className="text-xs text-gray-500">Order: {lesson.order}</span>
                                              </div>
                                              <Button 
                                                variant="ghost" 
                                                size="icon" 
                                                onClick={() => deleteLesson(module.id, lesson.id)}
                                              >
                                                <Trash2 className="h-4 w-4" />
                                              </Button>
                                            </div>
                                            
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                              <div className="space-y-3">
                                                <div className="space-y-1">
                                                  <label className="text-xs font-medium">Title</label>
                                                  <Input 
                                                    value={lesson.title}
                                                    onChange={(e) => updateLesson(
                                                      module.id, 
                                                      lesson.id, 
                                                      { title: e.target.value }
                                                    )}
                                                    className="h-8 text-sm"
                                                  />
                                                </div>
                                                <div className="space-y-1">
                                                  <label className="text-xs font-medium">Description</label>
                                                  <Textarea 
                                                    value={lesson.description}
                                                    onChange={(e) => updateLesson(
                                                      module.id, 
                                                      lesson.id, 
                                                      { description: e.target.value }
                                                    )}
                                                    className="h-20 text-sm min-h-0 resize-none"
                                                  />
                                                </div>
                                                <div className="space-y-1">
                                                  <label className="text-xs font-medium">Order</label>
                                                  <Input 
                                                    type="number"
                                                    min="1"
                                                    value={lesson.order}
                                                    onChange={(e) => updateLesson(
                                                      module.id, 
                                                      lesson.id, 
                                                      { order: parseInt(e.target.value) }
                                                    )}
                                                    className="h-8 text-sm"
                                                  />
                                                </div>
                                              </div>
                                              
                                              <div className="space-y-3">
                                                <div className="space-y-1">
                                                  <label className="text-xs font-medium">KSB Mapping</label>
                                                  <Select
                                                    onValueChange={(value) => {
                                                      const ksbId = parseInt(value);
                                                      if (!lesson.ksbIds.includes(ksbId)) {
                                                        updateLesson(module.id, lesson.id, { 
                                                          ksbIds: [...lesson.ksbIds, ksbId] 
                                                        });
                                                      }
                                                    }}
                                                  >
                                                    <SelectTrigger className="h-8 text-sm">
                                                      <SelectValue placeholder="Add KSB" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                      {standardKSBs.map((ksb) => (
                                                        <SelectItem key={ksb.id} value={ksb.id.toString()}>
                                                          {ksb.code}: {ksb.description.substring(0, 30)}...
                                                        </SelectItem>
                                                      ))}
                                                    </SelectContent>
                                                  </Select>
                                                  
                                                  <div className="flex flex-wrap gap-1 mt-1">
                                                    {lesson.ksbIds.map((ksbId) => {
                                                      const ksb = standardKSBs.find(k => k.id === ksbId);
                                                      return (
                                                        <Badge 
                                                          key={ksbId} 
                                                          variant="outline"
                                                          className="text-xs flex items-center gap-1"
                                                        >
                                                          {ksb?.code || `KSB-${ksbId}`}
                                                          <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="h-3 w-3 p-0"
                                                            onClick={() => updateLesson(module.id, lesson.id, { 
                                                              ksbIds: lesson.ksbIds.filter(id => id !== ksbId) 
                                                            })}
                                                          >
                                                            <Trash2 className="h-2 w-2" />
                                                          </Button>
                                                        </Badge>
                                                      );
                                                    })}
                                                  </div>
                                                </div>
                                                
                                                {lesson.type === "resource" && (
                                                  <div className="space-y-1 pt-2">
                                                    <label className="text-xs font-medium">Resource Type</label>
                                                    <Select
                                                      value={lesson.resourceType || "article"}
                                                      onValueChange={(value) => updateLesson(
                                                        module.id, 
                                                        lesson.id, 
                                                        { resourceType: value }
                                                      )}
                                                    >
                                                      <SelectTrigger className="h-8 text-sm">
                                                        <SelectValue />
                                                      </SelectTrigger>
                                                      <SelectContent>
                                                        <SelectItem value="article">Article</SelectItem>
                                                        <SelectItem value="video">Video</SelectItem>
                                                        <SelectItem value="document">Document</SelectItem>
                                                        <SelectItem value="link">External Link</SelectItem>
                                                      </SelectContent>
                                                    </Select>
                                                  </div>
                                                )}
                                                
                                                {lesson.type === "assessment" && (
                                                  <div className="space-y-1 pt-2">
                                                    <label className="text-xs font-medium">Assessment Type</label>
                                                    <Select
                                                      value={lesson.assessmentType || "quiz"}
                                                      onValueChange={(value) => updateLesson(
                                                        module.id, 
                                                        lesson.id, 
                                                        { assessmentType: value }
                                                      )}
                                                    >
                                                      <SelectTrigger className="h-8 text-sm">
                                                        <SelectValue />
                                                      </SelectTrigger>
                                                      <SelectContent>
                                                        <SelectItem value="quiz">Quiz</SelectItem>
                                                        <SelectItem value="assignment">Assignment</SelectItem>
                                                        <SelectItem value="reflection">Reflection</SelectItem>
                                                        <SelectItem value="project">Project</SelectItem>
                                                      </SelectContent>
                                                    </Select>
                                                  </div>
                                                )}
                                                
                                                {lesson.type === "content" && (
                                                  <div className="space-y-1 pt-2">
                                                    <label className="text-xs font-medium">AI-Generated Outline</label>
                                                    <Button 
                                                      variant="outline" 
                                                      size="sm" 
                                                      className="w-full h-8 text-xs"
                                                      onClick={() => {
                                                        if (lesson.ksbIds.length > 0) {
                                                          // TODO: Call AI to generate content outline
                                                          toast({
                                                            title: "Coming Soon",
                                                            description: "AI content generation is coming soon",
                                                          });
                                                        } else {
                                                          toast({
                                                            title: "Required",
                                                            description: "Please map at least one KSB to generate content",
                                                            variant: "destructive",
                                                          });
                                                        }
                                                      }}
                                                    >
                                                      <Wand2 className="mr-1 h-3 w-3" />
                                                      Generate Content Outline
                                                    </Button>
                                                  </div>
                                                )}
                                              </div>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </>
                                );
                              })()}
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="templates">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {templatesLoading ? (
                    <div>Loading templates...</div>
                  ) : templates?.length === 0 ? (
                    <Card className="col-span-full">
                      <CardContent className="pt-6">
                        <div className="text-center py-8">
                          <Layers className="mx-auto h-12 w-12 text-gray-400" />
                          <h3 className="mt-2 text-xl font-medium">No templates available</h3>
                          <p className="mt-1 text-gray-500">
                            Create your first course template using the Course Builder tab
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    templates?.map((template: any) => (
                      <Card key={template.id}>
                        <CardHeader>
                          <CardTitle>{template.title}</CardTitle>
                          <CardDescription>{template.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-500">Standard:</span>
                              <span className="font-medium">
                                {template.standard?.title || "Unknown"}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-500">Modules:</span>
                              <span className="font-medium">
                                {template.modules?.length || 0}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-500">Created by:</span>
                              <span className="font-medium">
                                {template.createdBy?.firstName} {template.createdBy?.lastName}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-500">Public:</span>
                              <span className="font-medium">
                                {template.isPublic ? "Yes" : "No"}
                              </span>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button
                            variant="outline"
                            className="w-full"
                            onClick={() => {
                              setSelectedTemplate(template);
                              // Load template data
                              form.reset({
                                title: `Copy of ${template.title}`,
                                description: template.description,
                                standardId: template.standardId,
                                isPublic: false,
                                includeResources: true,
                                includeAssessments: true,
                              });
                              
                              if (template.modules) {
                                setCourseModules(template.modules);
                              }
                              
                              setActiveTab("builder");
                              toast({
                                title: "Template Loaded",
                                description: "The template has been loaded into the builder",
                              });
                            }}
                          >
                            Use Template
                          </Button>
                        </CardFooter>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>

      <AppFooter />
    </div>
  );
}